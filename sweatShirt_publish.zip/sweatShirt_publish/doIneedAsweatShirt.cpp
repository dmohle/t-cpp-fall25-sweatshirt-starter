// doIneedAsweatShirt.cpp
// dH 10/6/25
//
// CIT-66 — Fresno City College
// Lesson: Client/Server Programming in Modern C++
//
// This program demonstrates how a C++ client can connect to a remote web server,
// make an HTTPS request, and process JSON data from the response.
//
// We connect to the National Weather Service (NWS) API and ask for a weather forecast
// for Fresno, CA. The program prints the current temperature and a friendly
// “Do I need a sweatshirt?” recommendation.
//
// Concepts covered:
//  • HTTP/HTTPS networking
//  • Secure sockets (TLS/SSL)
//  • REST APIs
//  • JSON data parsing
//  • Client–Server architecture in practice
//

#include <curl/curl.h>         // libcurl handles all HTTP/HTTPS communication
#include <nlohmann/json.hpp>   // JSON parsing library (header-only)
#include <iostream>
#include <string>
#include <windows.h>            // for SetConsoleOutputCP (Windows UTF-8 console)
#include <filesystem>           // for working with relative file paths

using namespace std;
using json = nlohmann::json;
namespace fs = std::filesystem;

// -----------------------------------------------------------------------------
// HOW THE CLIENT/SERVER MODEL WORKS:
//
// In this program, your C++ program acts as the CLIENT.
// The National Weather Service (NWS) API is the SERVER.
//
// The client sends an HTTP request (over HTTPS, which means the data is encrypted)
// and the server replies with a JSON document containing the forecast.
// -----------------------------------------------------------------------------


// libcurl requires a callback function that it calls whenever data is received
// from the server. This function stores the incoming bytes into a std::string.
size_t WriteCallback(void* contents, size_t size, size_t nmemb, string* output) {
    size_t totalSize = size * nmemb;
    output->append(static_cast<char*>(contents), totalSize);
    return totalSize;
}


// Performs an HTTPS GET request to the given URL and returns the server’s response.
string httpGet(const string& url) {

    // Initialize a CURL “easy” session — the main object that represents the connection.
    CURL* curl = curl_easy_init();

    // Locate the SSL certificate bundle (required for secure HTTPS connections).
    // This tells libcurl which Certificate Authorities (CAs) to trust when verifying
    // the server’s digital certificate. Without this, HTTPS verification fails.
    fs::path certPath = fs::current_path().parent_path() / "certs" / "cacert.pem";
    cout << "Using CA cert: " << certPath << endl;
    curl_easy_setopt(curl, CURLOPT_CAINFO, certPath.string().c_str());

    string response;  // The full text returned by the server will be stored here.

    if (curl) {
        // ----------------- CLIENT → SERVER REQUEST SETUP -----------------

        // The URL of the API endpoint (the “address” of the web server).
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

        // Identify yourself — many public APIs require a “User-Agent” header.
        curl_easy_setopt(curl, CURLOPT_USERAGENT,
            "FresnoCityCollege-CIT66/1.0 (professor.mohle@fresnocitycollege.edu)");

        // Follow HTTP redirects automatically (e.g., if the server sends a 302).
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

        // Tell libcurl where to send the incoming bytes (our callback function).
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

        // ----------------- SERVER → CLIENT RESPONSE -----------------
        // Send the request and wait for the response.
        // This is the moment when your program communicates over the Internet.
        CURLcode res = curl_easy_perform(curl);

        // If something went wrong (bad URL, network error, SSL failure, etc.)
        if (res != CURLE_OK)
            cerr << "curl error: " << curl_easy_strerror(res) << endl;

        // Clean up the CURL session to free memory.
        curl_easy_cleanup(curl);
    } else {
        cerr << "Failed to initialize curl" << endl;
    }

    return response;
}


// -----------------------------------------------------------------------------
// MAIN PROGRAM — The entry point for our client
// -----------------------------------------------------------------------------
int main() {

    // Enable UTF-8 output in Windows console so degree symbols (°) and em dashes (—)
    // display correctly instead of showing strange characters.
    SetConsoleOutputCP(CP_UTF8);

    // The National Weather Service divides the U.S. into forecast “gridpoints.”
    // HNX refers to the Hanford, CA weather office, and 53,100 is Fresno’s gridpoint.
    const string url = "https://api.weather.gov/gridpoints/HNX/53,100/forecast";

    // The client performs an HTTPS GET request to the NWS API.
    string response = httpGet(url);

    // If the response string is empty, it means the network request failed.
    if (response.empty()) {
        cerr << "No response from NWS API." << endl;
        return 1;
    }

    // -------------------------------------------------------------------------
    // The server’s reply is in JSON format.
    // JSON = JavaScript Object Notation — it’s a text-based data structure
    // used by almost every modern web API.
    // -------------------------------------------------------------------------
    json data;
    try {
        data = json::parse(response);  // Parse the text into a structured object
    } catch (const exception& e) {
        cerr << "JSON parse error: " << e.what() << endl;
        return 1;
    }

    // The forecast data lives inside the “properties.periods” array of the JSON object.
    auto periods = data["properties"]["periods"];
    if (periods.empty()) {
        cerr << "No forecast data found." << endl;
        return 1;
    }

    // Extract just the first forecast period (usually “Today” or “This Afternoon”).
    auto today = periods[0];
    int temp = today["temperature"];
    string unit = today["temperatureUnit"];
    string forecast = today["shortForecast"];
    string name = today["name"];

    // -------------------------------------------------------------------------
    // CLIENT-SIDE DATA PRESENTATION
    // -------------------------------------------------------------------------
    cout << "\n--- Fresno Forecast (" << name << ") ---" << endl;
    cout << "Temperature: " << temp << "°" << unit << endl;
    cout << "Conditions:  " << forecast << endl;

    // Simple business logic — the “app layer” that uses the data
    // to make a decision or give a user recommendation.
    if (temp < 60)
        cout << "Recommendation: YES — definitely wear a sweatshirt!" << endl;
    else if (temp < 70)
        cout << "Recommendation: PROBABLY — bring one just in case." << endl;
    else
        cout << "Recommendation: NO — it’s warm enough today." << endl;

    cout << "---------------------------------------" << endl;

    // Exit code 0 means success
    return 0;
}
